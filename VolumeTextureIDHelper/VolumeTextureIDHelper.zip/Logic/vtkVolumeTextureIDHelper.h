
#ifndef __vtkVolumeTextureIDHelper_h
#define __vtkVolumeTextureIDHelper_h

#include <vtkObject.h>
#include <vtkSmartPointer.h>
#include <vtkMRMLVolumeNode.h>
#include <vtkOpenGLGPUVolumeRayCastMapper.h>

class vtkVolumeTextureIDHelper : public vtkObject
{
public:
  static vtkVolumeTextureIDHelper* New();
  vtkTypeMacro(vtkVolumeTextureIDHelper, vtkObject);

  /// Gets the OpenGL texture ID used by the mapper in a specific view index
  GLuint GetTextureIdForVolume(vtkMRMLVolumeNode* volumeNode, int viewIndex);

protected:
  vtkVolumeTextureIDHelper() = default;
  ~vtkVolumeTextureIDHelper() override = default;

private:
  vtkVolumeTextureIDHelper(const vtkVolumeTextureIDHelper&) = delete;
  void operator=(const vtkVolumeTextureIDHelper&) = delete;
};

#endif
