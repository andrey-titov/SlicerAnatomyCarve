
#include "vtkVolumeTextureIDHelper.h"

#include <vtkMRMLScene.h>
#include <vtkMRMLVolumeNode.h>
#include <vtkMRMLViewNode.h>
#include <vtkMRMLVolumeRenderingDisplayNode.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkVolume.h>
#include <vtkVolumeCollection.h>
#include <vtkVolumeMapper.h>
#include <vtkOpenGLGPUVolumeRayCastMapper.h>
#include <qSlicerApplication.h>
#include <qSlicerLayoutManager.h>
#include <qMRMLThreeDView.h>

vtkStandardNewMacro(vtkVolumeTextureIDHelper);

GLuint vtkVolumeTextureIDHelper::GetTextureIdForVolume(vtkMRMLVolumeNode* volumeNode, int viewIndex)
{
  if (!volumeNode)
    return 0;

  qSlicerLayoutManager* layoutManager = qSlicerApplication::application()->layoutManager();
  if (!layoutManager || viewIndex >= layoutManager->threeDViewCount())
    return 0;

  qMRMLThreeDView* view = layoutManager->threeDWidget(viewIndex)->threeDView();
  vtkRenderer* renderer = view->renderer();

  vtkVolumeCollection* volumes = renderer->GetVolumes();
  volumes->InitTraversal();

  while (vtkVolume* actor = volumes->GetNextVolume())
  {
    vtkVolumeMapper* mapper = actor->GetMapper();
    vtkOpenGLGPUVolumeRayCastMapper* glMapper = vtkOpenGLGPUVolumeRayCastMapper::SafeDownCast(mapper);
    if (!glMapper)
      continue;

    if (glMapper->GetTextureObject(0))
    {
      return glMapper->GetTextureObject(0)->GetHandle();
    }
  }

  return 0;
}
